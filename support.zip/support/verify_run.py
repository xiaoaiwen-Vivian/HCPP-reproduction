"""Xiaoai: validate newly generated data and results without reading old 0507 data."""
from pathlib import Path
import argparse, json, re
import numpy as np
import pandas as pd

def main():
    ap=argparse.ArgumentParser();ap.add_argument('package',type=Path);ap.add_argument('run',type=Path);ap.add_argument('--build-only',action='store_true');a=ap.parse_args()
    checks=[]
    def check(name,value):
        checks.append({'check':name,'passed':bool(value)})
    def compare(name,got,want):
        if isinstance(want,dict):
            for key,value in want.items():compare(f'{name}.{key}',got.get(key),value)
        elif isinstance(want,list):
            check(name+'.length',len(got)==len(want))
            for i,(x,y) in enumerate(zip(got,want)):compare(f'{name}[{i}]',x,y)
        elif want is None or isinstance(want,float) and np.isnan(want):check(name,got is None or pd.isna(got))
        elif isinstance(want,(int,float)) and not isinstance(want,bool):
            check(name,got is not None and np.isclose(float(got),float(want),rtol=1e-6,atol=1e-8))
        else:check(name,got==want)
    log=(a.run/'logs'/('pipeline_build.log' if a.build_only else 'pipeline_.log')).read_text(errors='replace')
    check('no_unhandled_stata_error',not re.search(r'^r\(\d+\);',log,re.M))
    sentinel='RAW_TO_0507_COMPLETED' if a.build_only else 'HCPP_RAW_0507_ALL_FINAL_MODELS_COMPLETED'
    check('completed_sentinel','\n'+sentinel+'\n' in log)
    charls=pd.read_stata(a.run/'data/charls.dta',convert_categoricals=False)
    data=pd.read_stata(a.run/'data/dataset 0507.dta',convert_categoricals=False)
    person=data.ID.notna() & data.ID.ne('') & data.wave.notna()
    check('charls_rows',len(charls)==96628);check('0507_rows',len(data)==86696)
    check('identified_person_waves',person.sum()==85386)
    check('environment_only_rows',(~person).sum()==1310)
    check('unique_person_wave_keys',not data.loc[person].duplicated(['ID','wave']).any())
    if not a.build_only:
        o=a.run/'output';expected=json.loads((a.package/'verification/EXPECTED_RESULTS.json').read_text())
        primary=pd.read_stata(o/'primary_estimation_sample.dta',convert_categoricals=False)
        check('primary_observations',len(primary)==16661);check('primary_people',primary.ID.nunique()==7995)
        check('primary_age_eligible',primary.age.notna().all() and primary.age.ge(45).all())
        check('primary_urban',primary.rural.eq(0).all())
        maps={'main':'main_DID_city_cluster.xlsx','PSM':'prepolicy_means_psmdid_summary.xlsx','heterogeneity_interactions':'heterogeneity_interactions_city_cluster.xlsx','mediation':'city_bootstrap_indirect_FDR.csv','wild_bootstrap':'main_did_wild_cluster_results.csv','nonlinear':'nonlinear_cityFE_citycluster.csv','individual_FE':'individual_FE_citycluster.xlsx','covid':'covid_centered_model_summary.csv'}
        for key,name in maps.items():
            frame=pd.read_csv(o/name) if name.endswith('.csv') else pd.read_excel(o/name)
            rows=frame.to_dict('records');compare(key,rows[0] if key in ['main','PSM'] else rows,expected[key])
        compare('event_pretrend_p',pd.read_excel(o/'event_study_city_cluster.xlsx').Joint_pretrend_P.iloc[0],expected['event_pretrend_p'])
        pl=pd.read_csv(o/'city_level_placebo_5000.csv')
        check('placebo_5000_valid',len(pl)==5000 and pl.valid_draw.eq(1).all())
        check('placebo_10_treated',pl.treated_cities.eq(10).all())
        main=pd.read_excel(o/'main_DID_city_cluster.xlsx').iloc[0]
        compare('placebo_coefficient_p',(np.count_nonzero(np.abs(pl.beta)>=abs(main.DID))+1)/5001,expected['placebo']['coefficient_p'])
        compare('placebo_studentized_p',(np.count_nonzero(np.abs(pl.t)>=abs(main.DID/main.City_cluster_SE))+1)/5001,expected['placebo']['studentized_p'])
        fast=json.loads((o/'city_placebo_fast_validation.json').read_text());check('placebo_independent_stata_check',fast['passed'] and fast['verified_draws']>=20)
        med=pd.read_csv(o/'city_bootstrap_indirect_FDR.csv');check('all_mediation_2000_valid',med.Reps.eq(2000).all() and med.Failed_Reps.eq(0).all())
        check('no_fdr_significant_mediation',med.FDR_Q.gt(.05).all())
        required=['full_chow_tests_city_cluster.xlsx','income_missingness_by_wave_treatment.xlsx','retained_vs_income_missing.xlsx','placebo_policy_timing_results.xlsx','prepolicy_psm_balance.xlsx','prepolicy_psm_diagnostics.dta','prepolicy_psm_balance.png','prepolicy_psm_overlap.png','covid_centered_marginal_effects.csv','mechanism_panelAB_city_cluster.xlsx']
        for name in required:check('output_present.'+name,(o/name).is_file() and (o/name).stat().st_size>0)
    report={'maintainer':'Xiaoai','passed':all(x['passed'] for x in checks),'mode':'build' if a.build_only else 'full','checks':checks,'comparison':'Aggregate reference results only. No old 0507, old charls or individual reference dataset is read. Expected values are checked after estimation, never used for selection.'}
    (a.run/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    failed=[x['check'] for x in checks if not x['passed']]
    if failed:raise SystemExit('Verification failed: '+', '.join(failed))
    (a.run/'verification_passed.ok').write_text('All checks passed.\n')
    print(f'Verified {len(checks)} checks; all data were generated in the new run directory.')

if __name__=='__main__':main()
